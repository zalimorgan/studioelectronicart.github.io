import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Processing_Drawing extends PApplet {

/* Based on stock example sketch 'Pulses' and YouTube Channel 'Coding Train's' videos on Perlin Noise.*/
float incr = 0.01f;
int red = color(216,56,56);
int blue = color(24,160,246);
int dark = color(2,24,43);
float time = (second()/ width *TWO_PI);
float inc = 0.1f;

public void setup()
{
  
  background(dark);
}

public void draw()
{
  float xoff = noise(radians(inc));
  float yoff = cos(xoff) * TWO_PI;
        {
        noFill();
        stroke(blue);
        strokeWeight(0.2f);
        arc(mouseX, mouseY += yoff, pmouseX += xoff, pmouseY += yoff,0,HALF_PI);
        }
        {
        noFill();
        stroke(red);
        strokeWeight(0.4f);
        arc(mouseX, mouseY += yoff, pmouseX += xoff, pmouseY += yoff, 0+HALF_PI, PIE);
        }
    xoff *= time;
    inc += 0.1f;
}
  public void settings() {  size(800, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Processing_Drawing" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
